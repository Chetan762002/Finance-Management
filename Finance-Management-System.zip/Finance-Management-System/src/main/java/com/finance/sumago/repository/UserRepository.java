package com.finance.sumago.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.finance.sumago.model.User;

public interface UserRepository extends JpaRepository<User, Long> {
    // Add custom query methods if needed
}
