package com.finance.sumago.service;

import com.finance.sumago.model.User;

public interface UserService {
    void registerUser(User user);
    // Add other methods as needed
}
