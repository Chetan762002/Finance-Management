package com.finance.sumago;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;

@SpringBootApplication
@EntityScan("com.finance.sumago.model")
public class FinanceManagementSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(FinanceManagementSystemApplication.class, args);
	}

}
